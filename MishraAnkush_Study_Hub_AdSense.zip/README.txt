# MishraAnkush Study Hub

A single-file responsive starter website for a NEB Class 11/12 learning platform.

## AdSense
The supplied Google AdSense script is already included in the `<head>` of `index.html`.

## Deploy with GitHub + Vercel
1. Upload `index.html` to your GitHub repository.
2. Commit the change.
3. Vercel will automatically deploy if the repository is connected.
4. After deployment, check the AdSense site status and follow Google's review/ads setup process.

## Important
The Nexa AI interface is a front-end UI only. It does not make live AI requests until an AI/search backend is connected.
